<?php
$config["database"] = [
    'serverName' => '26.237.235.80,1436',
    //'serverName' => 'DESKTOP-65O9QUO',
    'uid'=> 'sa',
    'pass'=> '12345',
    //'db'=> 'QuarantineCampDatabase'
    'db'=> 'QuarantineCamp'

];
?>