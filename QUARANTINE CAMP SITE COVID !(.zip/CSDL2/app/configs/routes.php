<?php 
$routes['default_controller'] = 'home';
$routes['home'] = 'home/index'; 
$routes['patient'] = 'patient/list1'; 
$routes['patient/detail'] = 'patient/detail'; 
$routes['form'] = 'form/index'; 
$routes['room'] = 'room/index'; 
$routes['patient/test'] = 'patient/test';
$routes['add'] ='form/add';
$routes['search'] ='patient/search';

?>

