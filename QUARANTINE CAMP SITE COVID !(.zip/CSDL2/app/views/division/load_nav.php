<?php
// Đọc nội dung từ tệp nav.php
$navContent = file_get_contents("nav.php");

// Trả về nội dung dưới dạng phản hồi JSON
echo json_encode(['navContent' => $navContent]);
?>
