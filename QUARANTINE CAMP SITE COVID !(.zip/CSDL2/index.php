<?php 
session_start();
require_once 'bootstrap.php';
require_once 'app/App.php';
$app = new App();
?>
